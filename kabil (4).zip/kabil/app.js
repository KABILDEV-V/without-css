const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');

const app = express();

const storage = multer.diskStorage({
  destination: './uploads',
  filename: function (req, file, callback) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    callback(null, file.fieldname + '-' + uniqueSuffix + ext);
  }
});

const upload = multer({ storage });

app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'hj.html'));
});

app.post('/upload', upload.single('image'), (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }

  const source = req.file.path;
  const destination = path.join(__dirname, 'local-storage', req.file.filename);

  fs.copyFile(source, destination, (err) => {
    if (err) {
      console.error('Error copying file:', err);
      return res.status(500).send('Error uploading file.');
    }

    res.send('File uploaded successfully.');
  });
});

app.get('/image', (req, res) => {
  const imagePath = path.join(__dirname, 'local-storage', 'image-1689351203535-829099906.jpg'); // Replace 'image.jpg' with the actual filename

  fs.readFile(imagePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Image not found.');
    } else {
      res.writeHead(200, { 'Content-Type': 'image/jpeg' }); // Set the appropriate content type based on the image format
      res.end(data);
    }
  });
});

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
});
